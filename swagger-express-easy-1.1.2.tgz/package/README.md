# 🚀 swagger-express-easy

The easiest way to add **OpenAPI 3.0** documentation to your Express application. 
Stop writing manual JSON/YAML — just write your code, and let us handle the rest.

[![npm version](https://img.shields.io/npm/v/swagger-express-easy.svg)](https://www.npmjs.com/package/swagger-express-easy)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## ✨ Features

- **Auto-Generation**: Automatically scans your Express routes.
- **Watch Mode**: Live updates to Swagger UI as you code.
- **Type-Safe Schemas**: Define reusable Entities with a simple API.
- **Programmatic Metadata**: Annotate routes directly in your route files.
- **File Upload Support**: Easy documentation for `multipart/form-data`.
- **Zero Configuration**: Smart defaults from your `package.json`.

---

## 📦 Installation

```bash
npm install swagger-express-easy
```

---

## 🚀 Quick Start

### 1. Initialize in `app.ts`

```typescript
import express from 'express';
import { SwaggerAuto } from 'swagger-express-easy';

const app = express();

const swagger = new SwaggerAuto(app, {
  path: '/api-docs', // Where the UI lives
  watch: true,       // Enable live updates
  endpointsRoutes: ['./src/routes/*.ts'], // Where your routes are
});

async function start() {
  await swagger.setup();
  app.listen(3000, () => console.log('Server & Swagger running!'));
}
start();
```

---

## 🛠️ Advanced Usage

### Reusable Schemas (Entities)

Define your models once and reuse them everywhere.

```typescript
import { defineSchema, schemaRef } from 'swagger-express-easy';

// Define the schema
defineSchema('User', {
  id: { type: 'integer', required: true, example: 1 },
  username: { type: 'string', required: true, example: 'johndoe' },
  email: { type: 'string', format: 'email' }
});

// Use it in a route
createSwaggerRoute({
  method: 'get',
  path: '/api/users/{id}',
  body: { $ref: schemaRef('User') }
});
```

### File Uploads

Documenting file uploads is a breeze.

```typescript
createSwaggerRoute({
  method: 'post',
  path: '/api/upload',
  consumes: ['multipart/form-data'],
  parameters: [
    {
      name: 'file',
      in: 'formData',
      type: 'file',
      required: true,
      description: 'The file to upload'
    }
  ],
  tags: ['Files']
});
```

### Decorators & Wrappers

If you prefer keeping your documentation right next to your logic, you can use our built-in wrappers and decorators!

#### 1. Wrapper (For Standard Functions)
```typescript
import { withSwagger } from 'swagger-express-easy';

export const getHello = withSwagger({
  method: 'get',
  path: '/api/hello',
  description: { text: 'Returns a hello message' }
}, (req, res) => {
  res.json({ message: 'Hello World!' });
});
```

#### 2. Class Decorator (For ES6 Classes)
```typescript
import { SwaggerRoute } from 'swagger-express-easy';

class UserController {
  @SwaggerRoute({ method: 'get', path: '/api/users', tags: ['Users'] })
  getUsers(req: Request, res: Response) {
    res.json([]);
  }
}
```

---


## ⚙️ Configuration Options

| Option | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `path` | `string` | `'/api-docs'` | The URL path for Swagger UI. |
| `watch` | `boolean` | `false` | Regenerate docs on every request to `path`. |
| `outputFile` | `string` | `'swagger-output.json'` | Filename for the generated JSON. |
| `outputDir` | `string` | `process.cwd()` | Directory for the output file. |
| `endpointsRoutes`| `string[]` | `['./src/app.ts', ...]` | Glob patterns to scan for routes. |
| `bearerAuth` | `boolean` | `true` | Automatically add JWT Bearer auth to spec. |

---

## 🧪 Running Tests

```bash
npm test
```

## 📄 License

MIT © [Eyal Shapiro](https://github.com/EyalShapiro)
